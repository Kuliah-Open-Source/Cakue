<h1>Finance App</h1>

<h3>
this project i creat an awesome  Finance App UI and backend
</h3>
<p>
tutorial :
https://www.youtube.com/watch?v=9-QFt-cWZV8&ab_channel=flutterskills
</p>
<hr>
<div style = ""> 
<img src="https://user-images.githubusercontent.com/102475069/196632952-349c0bf9-a0a2-45d2-a0c1-3f7e34dd823c.png" alt="" width="32%"/>
<img src="https://user-images.githubusercontent.com/102475069/196633092-f933f964-5930-4686-8ce8-9e702ebfb1b7.png" alt="Screenshot_1659640778" width="32%"/>
<img src="https://user-images.githubusercontent.com/102475069/196633198-ff6e1bdd-cad5-4085-b9d1-df5bd793f971.png" alt="Screenshot_1666104775" width="32%"/>
</div>
